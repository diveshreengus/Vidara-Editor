package com.vidara.editor.ui
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.compose.*
import com.vidara.editor.ui.editor.EditorScreen
import com.vidara.editor.ui.home.HomeScreen
import com.vidara.editor.ui.projects.ProjectsScreen
import com.vidara.editor.ui.projects.ProjectsViewModel
import com.vidara.editor.ui.templates.TemplatesScreen

private data class Tab(val route: String, val label: String, val icon: ImageVector)

@Composable
fun AppNav() {
    val nav = rememberNavController()
    val vm: ProjectsViewModel = hiltViewModel()
    val tabs = listOf(
        Tab("home", "Home", Icons.Default.Home),
        Tab("templates", "Templates", Icons.Default.Star),
        Tab("create", "Create", Icons.Default.Add),
        Tab("projects", "Projects", Icons.AutoMirrored.Filled.List),
        Tab("profile", "Profile", Icons.Default.Person),
    )
    val backEntry by nav.currentBackStackEntryAsState()
    val route = backEntry?.destination?.route
    val showBar = route?.startsWith("editor") != true

    fun newProject() { vm.create { id -> nav.navigate("editor/$id") } }

    Scaffold(bottomBar = {
        if (showBar) NavigationBar {
            tabs.forEach { t ->
                NavigationBarItem(
                    selected = route == t.route, label = { Text(t.label) },
                    icon = { Icon(t.icon, t.label) },
                    onClick = { if (t.route == "create") newProject() else nav.navigate(t.route) { launchSingleTop = true } },
                )
            }
        }
    }) { pad ->
        NavHost(nav, startDestination = "home", modifier = Modifier.padding(pad)) {
            composable("home") { HomeScreen(onNew = { newProject() }, onOpen = { nav.navigate(it) }) }
            composable("templates") { TemplatesScreen() }
            composable("projects") { ProjectsScreen(vm) { nav.navigate("editor/$it") } }
            composable("profile") { Text("Profile & Settings — coming in a later phase", Modifier.padding(16.dp)) }
            composable("editor/{projectId}") { EditorScreen(onBack = { nav.popBackStack() }) }
        }
    }
}
