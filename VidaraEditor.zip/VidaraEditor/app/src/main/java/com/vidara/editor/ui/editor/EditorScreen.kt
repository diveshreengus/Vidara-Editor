package com.vidara.editor.ui.editor
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.vidara.editor.domain.Clip
import com.vidara.editor.domain.TrackType
import kotlinx.coroutines.delay
import java.io.File

@androidx.annotation.OptIn(UnstableApi::class)
@Composable
fun EditorScreen(onBack: () -> Unit, vm: EditorViewModel = hiltViewModel()) {
    val ctx = LocalContext.current
    val project by vm.project.collectAsState()
    val selected by vm.selected.collectAsState()
    val missing by vm.missingCount.collectAsState()
    val history by vm.history.collectAsState()
    val player = remember { ExoPlayer.Builder(ctx).build() }
    DisposableEffect(Unit) { onDispose { player.release() } }

    val clips: List<Clip> = project?.tracks?.firstOrNull { it.type == TrackType.VIDEO }?.clips.orEmpty()

    var playheadMs by remember { mutableLongStateOf(0L) }
    LaunchedEffect(clips) {
        while (true) {
            val i = player.currentMediaItemIndex
            playheadMs = clips.take(i).sumOf { it.durationMs } + player.currentPosition.coerceAtLeast(0)
            delay(60)
        }
    }

    // Rebuild the preview playlist whenever the edit list changes, keeping the playhead.
    LaunchedEffect(clips) {
        val keep = playheadMs
        player.setMediaItems(clips.map { c ->
            val b = MediaItem.Builder().setUri(Uri.fromFile(File(c.sourcePath ?: "")))
            if (c.isImage) b.setImageDurationMs(c.durationMs)
            else b.setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(c.inMs).setEndPositionMs(c.inMs + c.durationMs).build())
            b.build()
        })
        player.prepare()
        seekGlobal(player, clips, keep)
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(20)) { vm.addMedia(it) }
    var isPlaying by remember { mutableStateOf(false) }
    DisposableEffect(player) {
        val l = object : Player.Listener { override fun onIsPlayingChanged(p: Boolean) { isPlaying = p } }
        player.addListener(l); onDispose { player.removeListener(l) }
    }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("Back") }
            Text(project?.name ?: "", Modifier.weight(1f))
            TextButton(onClick = vm::undo, enabled = history.first > 0) { Text("Undo") }
            TextButton(onClick = vm::redo, enabled = history.second > 0) { Text("Redo") }
            Button(onClick = { /* Phase 4: Media3 Transformer export */ }, enabled = false) { Text("Export") }
        }
        if (missing > 0) Text("$missing clip(s) have missing media", color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(8.dp))

        Box(Modifier.weight(1f).fillMaxWidth().background(Color.Black), contentAlignment = Alignment.Center) {
            if (clips.isEmpty()) Text("Tap “Add media” to start")
            else AndroidView(factory = { PlayerView(it).apply { this.player = player; useController = false } }, modifier = Modifier.fillMaxSize())
        }

        Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = { if (isPlaying) player.pause() else player.play() }, enabled = clips.isNotEmpty()) { Text(if (isPlaying) "Pause" else "Play") }
            Text("${fmt(playheadMs)} / ${fmt(project?.durationMs ?: 0)}")
        }

        val total = (project?.durationMs ?: 0L).coerceAtLeast(1L)
        Slider(
            value = playheadMs.toFloat().coerceIn(0f, total.toFloat()),
            onValueChange = { player.pause(); playheadMs = it.toLong(); seekGlobal(player, clips, it.toLong()) },
            valueRange = 0f..total.toFloat(), enabled = clips.isNotEmpty(), modifier = Modifier.padding(horizontal = 8.dp))
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(8.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            clips.forEach { c ->
                val shape = RoundedCornerShape(8.dp)
                Box(Modifier.width((c.durationMs / 40).coerceAtLeast(40).dp).height(56.dp)
                    .background(MaterialTheme.colorScheme.surfaceVariant, shape)
                    .border(if (c.id == selected) 2.dp else 0.dp, MaterialTheme.colorScheme.primary, shape)
                    .clickable { vm.select(c.id) }, contentAlignment = Alignment.Center) {
                    Text(if (c.isImage) "IMG" else "VID", style = MaterialTheme.typography.labelSmall)
                }
            }
        }
        Row(Modifier.fillMaxWidth().navigationBarsPadding().horizontalScroll(rememberScrollState()).padding(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)) }) { Text("Add media") }
            Button(onClick = { vm.split(playheadMs) }, enabled = clips.isNotEmpty()) { Text("Split") }
            Button(onClick = vm::duplicateSelected, enabled = selected != null) { Text("Duplicate") }
            Button(onClick = vm::deleteSelected, enabled = selected != null) { Text("Delete") }
        }
    }
}

private fun seekGlobal(player: Player, clips: List<Clip>, globalMs: Long) {
    if (clips.isEmpty()) return
    var acc = 0L
    clips.forEachIndexed { i, c ->
        if (globalMs < acc + c.durationMs || i == clips.lastIndex) {
            player.seekTo(i, (globalMs - acc).coerceIn(0, c.durationMs)); return
        }
        acc += c.durationMs
    }
}

private fun fmt(ms: Long): String { val s = ms / 1000; return "%02d:%02d.%d".format(s / 60, s % 60, (ms % 1000) / 100) }
