package com.vidara.editor.ui.editor
import android.app.Application
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.vidara.editor.data.ProjectRepository
import com.vidara.editor.domain.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject

@HiltViewModel
class EditorViewModel @Inject constructor(
    private val repo: ProjectRepository,
    private val app: Application,
    saved: SavedStateHandle,
) : ViewModel() {
    private val projectId: String = checkNotNull(saved["projectId"])
    private val _project = MutableStateFlow<ProjectFile?>(null)
    val project = _project.asStateFlow()
    private val _selected = MutableStateFlow<String?>(null)
    val selected = _selected.asStateFlow()
    private val _missing = MutableStateFlow(0)
    val missingCount = _missing.asStateFlow()
    private val _history = MutableStateFlow(0 to 0)   // (undo size, redo size) for UI enablement
    val history = _history.asStateFlow()

    private val undoStack = ArrayDeque<ProjectFile>()
    private val redoStack = ArrayDeque<ProjectFile>()

    init {
        viewModelScope.launch {
            val p = repo.get(projectId)
            _project.value = p
            _missing.value = p?.let { repo.missingMedia(it).size } ?: 0
        }
    }

    fun select(id: String?) { _selected.value = id }

    private fun publishHistory() { _history.value = undoStack.size to redoStack.size }

    private fun commit(new: ProjectFile) {
        val old = _project.value ?: return
        if (new == old) return
        undoStack.addLast(old); if (undoStack.size > 100) undoStack.removeFirst()
        redoStack.clear()
        apply(new)
    }
    private fun apply(p: ProjectFile) {
        _project.value = p
        publishHistory()
        viewModelScope.launch { repo.save(p) }   // autosave on every change
    }

    fun undo() { val c = _project.value ?: return; val p = undoStack.removeLastOrNull() ?: return; redoStack.addLast(c); apply(p) }
    fun redo() { val c = _project.value ?: return; val n = redoStack.removeLastOrNull() ?: return; undoStack.addLast(c); apply(n) }

    fun split(positionMs: Long) { _project.value?.let { commit(Timeline.split(it, positionMs)) } }
    fun deleteSelected() { val id = _selected.value ?: return; _project.value?.let { commit(Timeline.delete(it, id)) }; _selected.value = null }
    fun duplicateSelected() { val id = _selected.value ?: return; _project.value?.let { commit(Timeline.duplicate(it, id)) } }

    /** Copies picked media into app storage (managed reference) and appends clips to the primary track. */
    fun addMedia(uris: List<Uri>) {
        viewModelScope.launch {
            val clips = withContext(Dispatchers.IO) { uris.mapNotNull { importOne(it) } }
            _project.value?.let { commit(Timeline.append(it, clips)) }
        }
    }

    private fun importOne(uri: Uri): Clip? = runCatching {
        val mime = app.contentResolver.getType(uri).orEmpty()
        val isImage = mime.startsWith("image/")
        val ext = if (isImage) "jpg" else "mp4"
        val dest = File(repo.mediaDir(), "${Timeline.newId()}.$ext")
        app.contentResolver.openInputStream(uri)!!.use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
        val dur = if (isImage) 5000L else {
            val r = MediaMetadataRetriever()
            try { r.setDataSource(dest.absolutePath); r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 0L }
            finally { r.release() }
        }
        if (dur <= 0) null else Clip(Timeline.newId(), dest.absolutePath, isImage, 0, dur)
    }.getOrNull()
}
