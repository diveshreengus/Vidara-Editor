package com.vidara.editor.ui.home
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp

@Composable
fun HomeScreen(onNew: () -> Unit, onOpen: (String) -> Unit) {
    val tiles = listOf("New Project", "AI Editing (soon)", "Templates", "Recent Projects", "My Projects",
        "Stock Media", "Music Library", "Effects Library", "Brand Kit", "Settings")
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(16.dp)) {
        Text("VIDARA Editor", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
        Text("Learn Smart, Learn Better", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(16.dp))
        LazyVerticalGrid(GridCells.Adaptive(150.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(tiles.size) { i ->
                Box(Modifier.height(88.dp).clip(RoundedCornerShape(16.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .clickable {
                        when (tiles[i]) {
                            "New Project" -> onNew()
                            "Templates" -> onOpen("templates")
                            "My Projects", "Recent Projects" -> onOpen("projects")
                        }
                    }, contentAlignment = Alignment.Center) { Text(tiles[i]) }
            }
        }
    }
}
