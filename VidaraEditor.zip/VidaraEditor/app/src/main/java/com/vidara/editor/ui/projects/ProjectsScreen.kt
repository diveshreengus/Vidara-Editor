package com.vidara.editor.ui.projects
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.vidara.editor.data.ProjectEntity
import com.vidara.editor.data.ProjectRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ProjectsViewModel @Inject constructor(private val repo: ProjectRepository) : ViewModel() {
    val projects: StateFlow<List<ProjectEntity>> =
        repo.observe().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    fun create(onDone: (String) -> Unit) {
        viewModelScope.launch { onDone(repo.create("Project ${projects.value.size + 1}").id) }
    }
    fun delete(id: String) { viewModelScope.launch { repo.delete(id) } }
}

@Composable
fun ProjectsScreen(vm: ProjectsViewModel, onOpen: (String) -> Unit) {
    val list by vm.projects.collectAsState()
    if (list.isEmpty()) { Text("No projects yet. Tap Create.", Modifier.padding(16.dp)); return }
    LazyColumn(Modifier.fillMaxSize().statusBarsPadding(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(list, key = { it.id }) { p ->
            Card(Modifier.fillMaxWidth().clickable { onOpen(p.id) }) {
                Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(p.name, Modifier.weight(1f))
                    TextButton(onClick = { vm.delete(p.id) }) { Text("Delete") }
                }
            }
        }
    }
}
