package com.vidara.editor.ui.templates
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.vidara.editor.template.TemplateRepository

@Composable
fun TemplatesScreen() {
    val ctx = LocalContext.current
    val templates = remember { TemplateRepository.loadInstalled(ctx) }
    LazyColumn(Modifier.fillMaxSize().statusBarsPadding(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Text("${templates.size} installed templates (offline)", style = MaterialTheme.typography.titleMedium) }
        items(templates, key = { it.id }) { t ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text(t.name, style = MaterialTheme.typography.titleSmall)
                    Text("${t.category} • ${t.width}x${t.height} • ${t.durationMs / 1000}s")
                }
            }
        }
    }
}
