package com.vidara.editor.ui.theme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val VidaraViolet = Color(0xFF7C5CFF)
val VidaraTeal = Color(0xFF18C5A0)
val Surface0 = Color(0xFF0E0F13)
val Surface1 = Color(0xFF171922)
val Surface2 = Color(0xFF22252F)

private val scheme = darkColorScheme(
    primary = VidaraViolet, secondary = VidaraTeal, background = Surface0,
    surface = Surface1, surfaceVariant = Surface2, onSurface = Color(0xFFECECF4),
    onBackground = Color(0xFFECECF4),
)

@Composable fun VidaraTheme(content: @Composable () -> Unit) =
    MaterialTheme(colorScheme = scheme, content = content)
