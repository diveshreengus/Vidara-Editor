package com.vidara.editor
import com.vidara.editor.domain.*
import org.junit.Assert.*
import org.junit.Test

class TimelineTest {
    private val base = ProjectFile(id = "p", name = "t")
    private fun clip(d: Long) = Clip(Timeline.newId(), "x.mp4", false, 0, d)

    @Test fun split_creates_two_clips_with_correct_ranges() {
        val p = Timeline.append(base, listOf(clip(10_000)))
        val s = Timeline.split(p, 4_000)
        val c = s.tracks.first().clips
        assertEquals(2, c.size)
        assertEquals(4_000, c[0].durationMs)
        assertEquals(4_000, c[1].inMs)
        assertEquals(6_000, c[1].durationMs)
        assertEquals(10_000, s.durationMs)
    }
    @Test fun split_near_edge_is_ignored() {
        val p = Timeline.append(base, listOf(clip(10_000)))
        assertEquals(p, Timeline.split(p, 50))
    }
    @Test fun delete_and_duplicate() {
        val p = Timeline.append(base, listOf(clip(1000)))
        val id = p.tracks.first().clips.first().id
        assertEquals(2, Timeline.duplicate(p, id).tracks.first().clips.size)
        assertEquals(0, Timeline.delete(p, id).tracks.first().clips.size)
    }
}
